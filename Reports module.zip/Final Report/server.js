const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/library_db', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => console.error('MongoDB connection error:', err));

// Student Attendance Schema
const attendanceSchema = new mongoose.Schema({
    name: { type: String, required: true },
    memberId: { type: String, required: true },
    date: { type: Date, required: true },
    entryTime: { type: String, required: true },
    exitTime: String,
    duration: Number,
    createdAt: { type: Date, default: Date.now }
});

const Attendance = mongoose.model('Attendance', attendanceSchema, 'student_attendance');

// API Routes
app.get('/api/attendance', async (req, res) => {
    try {
        // Get data from last 3 months by default
        const threeMonthsAgo = new Date();
        threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
        
        const attendance = await Attendance.find({
            date: { $gte: threeMonthsAgo }
        }).sort({ date: -1 });
        
        res.json(attendance);
    } catch (err) {
        console.error('Error fetching attendance:', err);
        res.status(500).json({ error: 'Failed to fetch attendance data' });
    }
});

app.get('/api/attendance/report', async (req, res) => {
    try {
        const { start, end } = req.query;
        
        if (!start || !end) {
            return res.status(400).json({ error: 'Start and end dates are required' });
        }
        
        const attendance = await Attendance.find({
            date: { 
                $gte: new Date(start),
                $lte: new Date(end)
            }
        }).sort({ date: -1 });
        
        res.json(attendance);
    } catch (err) {
        console.error('Error generating report:', err);
        res.status(500).json({ error: 'Failed to generate report' });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});