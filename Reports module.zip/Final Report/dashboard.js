// Global variables
let attendanceData = [];
let filteredData = [];

// DOM Content Loaded event
document.addEventListener('DOMContentLoaded', async function() {
    await fetchAttendanceData();
    initializeCharts();
    populateRecentActivity();
    populateStudentsTable();
});

// Tab functionality
function showTab(tabId) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Deactivate all tab buttons
    document.querySelectorAll('.tab-button').forEach(button => {
        button.classList.remove('active');
    });
    
    // Show selected tab content
    document.getElementById(tabId).classList.add('active');
    
    // Activate selected button
    event.currentTarget.classList.add('active');
    
    // Redraw charts when switching to overview tab
    if (tabId === 'overview') {
        setTimeout(() => {
            updateCharts();
        }, 100);
    }
}

// Fetch data from backend
async function fetchAttendanceData() {
    try {
        const response = await fetch('/api/attendance');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        attendanceData = data.map(record => ({
            ...record,
            date: new Date(record.date),
            duration: calculateDuration(record.entryTime, record.exitTime)
        }));
        filteredData = [...attendanceData];
    } catch (error) {
        console.error('Error fetching attendance data:', error);
        // Fallback to sample data if API fails
        attendanceData = getSampleData();
        filteredData = [...attendanceData];
    }
}

// Calculate duration between entry and exit
function calculateDuration(entryTime, exitTime) {
    if (!entryTime || !exitTime) return 0;
    
    const entry = new Date(`2000-01-01T${entryTime}`);
    const exit = new Date(`2000-01-01T${exitTime}`);
    
    // Handle cases where exit is next day (like 23:00 to 01:00)
    if (exit < entry) {
        exit.setDate(exit.getDate() + 1);
    }
    
    return (exit - entry) / (1000 * 60 * 60); // Return hours
}

// Initialize charts
function initializeCharts() {
    // Line Chart - Attendance Trend
    window.lineChart = new Chart(
        document.getElementById('lineChart'),
        {
            type: 'line',
            data: { labels: [], datasets: [] },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'top' }
                },
                scales: {
                    y: { beginAtZero: true, title: { display: true, text: 'Students' } }
                }
            }
        }
    );

    // Bar Chart - Daily Pattern
    window.barChart = new Chart(
        document.getElementById('barChart'),
        {
            type: 'bar',
            data: { labels: [], datasets: [] },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true, title: { display: true, text: 'Students' } }
                }
            }
        }
    );
}

// Update charts with data
function updateCharts() {
    if (!attendanceData.length) return;

    // Process data for charts
    const dailyData = processDailyData();
    const weeklyData = processWeeklyData();

    // Update Line Chart (Daily Trend)
    lineChart.data.labels = dailyData.labels;
    lineChart.data.datasets = [{
        label: 'Daily Student Attendance',
        data: dailyData.values,
        borderColor: 'rgb(54, 162, 235)',
        backgroundColor: 'rgba(54, 162, 235, 0.2)',
        tension: 0.1,
        fill: true
    }];
    lineChart.update();

    // Update Bar Chart (Weekly Pattern)
    barChart.data.labels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    barChart.data.datasets = [{
        data: weeklyData,
        backgroundColor: 'rgba(54, 162, 235, 0.7)'
    }];
    barChart.update();
}

// Process data for daily trend
function processDailyData() {
    const dailyMap = new Map();
    
    // Group by date
    filteredData.forEach(record => {
        const dateStr = record.date.toISOString().split('T')[0];
        if (!dailyMap.has(dateStr)) {
            dailyMap.set(dateStr, 0);
        }
        dailyMap.set(dateStr, dailyMap.get(dateStr) + 1);
    });
    
    // Convert to arrays for chart
    const labels = Array.from(dailyMap.keys()).sort();
    const values = labels.map(date => dailyMap.get(date));
    
    return { labels, values };
}

// Process data for weekly pattern
function processWeeklyData() {
    const weeklyCounts = [0, 0, 0, 0, 0, 0, 0]; // Sun-Sat
    
    filteredData.forEach(record => {
        const dayOfWeek = record.date.getDay(); // 0=Sun, 6=Sat
        weeklyCounts[dayOfWeek]++;
    });
    
    return weeklyCounts;
}

// Populate recent activity table
function populateRecentActivity() {
    const tableBody = document.querySelector('#attendanceHistoryTable tbody');
    tableBody.innerHTML = '';
    
    // Get most recent 10 records
    const recentRecords = [...filteredData]
        .sort((a, b) => b.date - a.date)
        .slice(0, 10);
    
    recentRecords.forEach(record => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${record.name}</td>
            <td>${record.studentId || 'N/A'}</td>
            <td>${formatDate(record.date)}</td>
            <td>${record.entryTime || 'N/A'}</td>
            <td>${record.exitTime || 'N/A'}</td>
            <td>${formatDuration(record.duration)}</td>
        `;
        
        tableBody.appendChild(row);
    });
}

// Populate students table
function populateStudentsTable() {
    const tableBody = document.getElementById('studentsTableBody');
    tableBody.innerHTML = '';
    
    filteredData.forEach(record => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${record.name}</td>
            <td>${record.studentId || 'N/A'}</td>
            <td>${formatDate(record.date)}</td>
            <td>${record.entryTime || 'N/A'}</td>
            <td>${record.exitTime || 'N/A'}</td>
            <td>${formatDuration(record.duration)}</td>
        `;
        
        tableBody.appendChild(row);
    });
}

// Filter students based on search input
function filterStudents() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    if (!searchTerm) {
        filteredData = [...attendanceData];
    } else {
        filteredData = attendanceData.filter(record =>
            record.name.toLowerCase().includes(searchTerm) ||
            (record.studentId && record.studentId.toLowerCase().includes(searchTerm))
        );
    }
    
    populateStudentsTable();
    updateCharts();
    populateRecentActivity();
}

// Generate custom report
async function generateReport() {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    
    try {
        const response = await fetch(`/api/attendance/report?start=${startDate}&end=${endDate}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const reportData = await response.json();
        displayReportResults(reportData);
    } catch (error) {
        console.error('Error generating report:', error);
        // Fallback to client-side filtering if API fails
        const filtered = attendanceData.filter(record => {
            const recordDate = record.date.toISOString().split('T')[0];
            return recordDate >= startDate && recordDate <= endDate;
        });
        displayReportResults(filtered);
    }
}

// Display report results
function displayReportResults(data) {
    const reportResults = document.getElementById('reportResults');
    
    if (!data.length) {
        reportResults.innerHTML = '<p>No records found for the selected date range.</p>';
        return;
    }
    
    // Calculate summary statistics
    const totalVisits = data.length;
    const uniqueStudents = new Set(data.map(record => record.studentId || record.name)).size;
    const avgDuration = data.reduce((sum, record) => sum + (record.duration || 0), 0) / totalVisits;
    
    // Create HTML
    let html = `
        <div class="report-summary">
            <h3>Summary (${formatDate(new Date(document.getElementById('startDate').value))} to ${formatDate(new Date(document.getElementById('endDate').value))})</h3>
            <div class="summary-stats">
                <div class="stat-card">
                    <h4>Total Visits</h4>
                    <p>${totalVisits}</p>
                </div>
                <div class="stat-card">
                    <h4>Unique Member</h4>
                    <p>${uniqueStudents}</p>
                </div>
                <div class="stat-card">
                    <h4>Avg Duration</h4>
                    <p>${formatDuration(avgDuration)}</p>
                </div>
            </div>
            <h4>Top Students by Visits</h4>
            <ul class="student-distribution">
    `;
    
    // Group by student
    const studentCounts = {};
    data.forEach(record => {
        const studentKey = record.studentId || record.name;
        studentCounts[studentKey] = (studentCounts[studentKey] || 0) + 1;
    });
    
    // Sort students by visit count
    const sortedStudents = Object.entries(studentCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5); // Show top 5
    
    sortedStudents.forEach(([student, count]) => {
        const percentage = ((count / totalVisits) * 100).toFixed(1);
        html += `
            <li>
                <span class="student-label">${student}</span>
                <span class="student-bar-container">
                    <span class="student-bar" style="width: ${percentage}%"></span>
                </span>
                <span class="student-count">${count} visits (${percentage}%)</span>
            </li>
        `;
    });
    
    html += `
            </ul>
        </div>
        <div class="report-details">
            <h3>Detailed Records (${data.length})</h3>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Member Name</th>
                            <th>Member ID</th>
                            <th>Date</th>
                            <th>Entry</th>
                            <th>Exit</th>
                            <th>Duration</th>
                        </tr>
                    </thead>
                    <tbody>
    `;
    
    data.slice(0, 50).forEach(record => {
        html += `
            <tr>
                <td>${record.name}</td>
                <td>${record.studentId || 'N/A'}</td>
                <td>${formatDate(record.date)}</td>
                <td>${record.entryTime || 'N/A'}</td>
                <td>${record.exitTime || 'N/A'}</td>
                <td>${formatDuration(record.duration)}</td>
            </tr>
        `;
    });
    
    if (data.length > 50) {
        html += `
            <tr>
                <td colspan="6">+ ${data.length - 50} more records...</td>
            </tr>
        `;
    }
    
    html += `
                    </tbody>
                </table>
            </div>
        </div>
    `;
    
    reportResults.innerHTML = html;
}

// Export data as CSV
function exportReport() {
    if (!filteredData.length) return;
    
    // Create CSV content
    let csv = 'Student Name,Student ID,Date,Entry Time,Exit Time,Duration (hours)\n';
    
    filteredData.forEach(record => {
        csv += `"${record.name}","${record.studentId || ''}","${formatDate(record.date)}","${record.entryTime || ''}","${record.exitTime || ''}","${record.duration || ''}"\n`;
    });
    
    // Create download link
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('hidden', '');
    a.setAttribute('href', url);
    a.setAttribute('download', 'student_attendance_export.csv');
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

// Helper function to format date
function formatDate(date) {
    if (!(date instanceof Date)) return 'N/A';
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

// Helper function to format duration
function formatDuration(hours) {
    if (!hours) return 'N/A';
    if (hours < 1) return `${Math.round(hours * 60)} mins`;
    if (hours % 1 === 0) return `${hours} hrs`;
    const wholeHours = Math.floor(hours);
    const minutes = Math.round((hours % 1) * 60);
    return `${wholeHours}h ${minutes}m`;
}

// Sample data for fallback
function getSampleData() {
    const names = [
        'Alex Johnson', 'Maria Garcia', 'James Smith', 
        'Sarah Williams', 'David Brown', 'Emma Jones'
    ];
    const studentIds = ['S1001', 'S1002', 'S1003', 'S1004', 'S1005', 'S1006'];
    
    const data = [];
    const startDate = new Date(2025, 0, 1); // Jan 1, 2025
    const endDate = new Date(2025, 2, 31); // Mar 31, 2025
    
    // Generate 100 sample records
    for (let i = 0; i < 100; i++) {
        const randomDate = new Date(startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime()));
        const randomIndex = Math.floor(Math.random() * names.length);
        const randomName = names[randomIndex];
        const randomStudentId = studentIds[randomIndex];
        
        // Generate random entry time between 8am and 8pm
        const entryHour = 8 + Math.floor(Math.random() * 12);
        const entryMinute = Math.floor(Math.random() * 60);
        const entryTime = `${entryHour.toString().padStart(2, '0')}:${entryMinute.toString().padStart(2, '0')}`;
        
        // Generate exit time 1-4 hours after entry
        const durationHours = 1 + Math.random() * 3;
        const exitTime = new Date(`2000-01-01T${entryTime}:00`);
        exitTime.setHours(exitTime.getHours() + durationHours);
        const exitTimeStr = `${exitTime.getHours().toString().padStart(2, '0')}:${exitTime.getMinutes().toString().padStart(2, '0')}`;
        
        data.push({
            name: randomName,
            studentId: randomStudentId,
            date: randomDate,
            entryTime: entryTime,
            exitTime: exitTimeStr,
            duration: durationHours
        });
    }
    
    return data;
}