const mongoose = require('mongoose');
require('dotenv').config();

// Connection URL
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/library_db');

// Student Attendance Model
const Attendance = mongoose.model('Attendance', new mongoose.Schema({
  name: { type: String, required: true },
  studentId: { type: String, required: true },
  date: { type: Date, required: true },
  entryTime: { type: String, required: true },
  exitTime: String,
  duration: Number,
  createdAt: { type: Date, default: Date.now }
}), 'student_attendance');

// Sample data (50 records)
const sampleData = [
  // January 2025
  { name: "Alex Johnson", studentId: "S1001", date: new Date("2025-01-05"), entryTime: "09:15", exitTime: "11:45", duration: 2.5 },
  { name: "Maria Garcia", studentId: "S1002", date: new Date("2025-01-05"), entryTime: "10:00", exitTime: "12:30", duration: 2.5 },
  { name: "James Smith", studentId: "S1003", date: new Date("2025-01-06"), entryTime: "08:30", exitTime: "11:00", duration: 2.5 },
  { name: "Sarah Williams", studentId: "S1004", date: new Date("2025-01-07"), entryTime: "13:00", exitTime: "15:30", duration: 2.5 },
  { name: "David Brown", studentId: "S1005", date: new Date("2025-01-08"), entryTime: "11:15", exitTime: "14:45", duration: 3.5 },
  { name: "Emma Jones", studentId: "S1006", date: new Date("2025-01-09"), entryTime: "14:00", exitTime: "16:30", duration: 2.5 },
  { name: "Alex Johnson", studentId: "S1001", date: new Date("2025-01-12"), entryTime: "09:30", exitTime: "12:00", duration: 2.5 },
  { name: "Maria Garcia", studentId: "S1002", date: new Date("2025-01-13"), entryTime: "10:45", exitTime: "13:15", duration: 2.5 },
  { name: "James Smith", studentId: "S1003", date: new Date("2025-01-14"), entryTime: "08:15", exitTime: "10:45", duration: 2.5 },
  { name: "Sarah Williams", studentId: "S1004", date: new Date("2025-01-15"), entryTime: "12:30", exitTime: "15:00", duration: 2.5 },

  // February 2025
  { name: "David Brown", studentId: "S1005", date: new Date("2025-02-02"), entryTime: "11:00", exitTime: "14:30", duration: 3.5 },
  { name: "Emma Jones", studentId: "S1006", date: new Date("2025-02-03"), entryTime: "13:45", exitTime: "16:15", duration: 2.5 },
  { name: "Alex Johnson", studentId: "S1001", date: new Date("2025-02-04"), entryTime: "09:00", exitTime: "12:30", duration: 3.5 },
  { name: "Maria Garcia", studentId: "S1002", date: new Date("2025-02-05"), entryTime: "10:30", exitTime: "13:00", duration: 2.5 },
  { name: "James Smith", studentId: "S1003", date: new Date("2025-02-09"), entryTime: "08:45", exitTime: "11:15", duration: 2.5 },
  { name: "Sarah Williams", studentId: "S1004", date: new Date("2025-02-10"), entryTime: "12:00", exitTime: "14:30", duration: 2.5 },
  { name: "David Brown", studentId: "S1005", date: new Date("2025-02-11"), entryTime: "11:30", exitTime: "15:00", duration: 3.5 },
  { name: "Emma Jones", studentId: "S1006", date: new Date("2025-02-12"), entryTime: "14:15", exitTime: "16:45", duration: 2.5 },
  { name: "Alex Johnson", studentId: "S1001", date: new Date("2025-02-16"), entryTime: "09:15", exitTime: "12:45", duration: 3.5 },
  { name: "Maria Garcia", studentId: "S1002", date: new Date("2025-02-17"), entryTime: "10:00", exitTime: "13:30", duration: 3.5 },

  // March 2025
  { name: "James Smith", studentId: "S1003", date: new Date("2025-03-03"), entryTime: "08:30", exitTime: "11:00", duration: 2.5 },
  { name: "Sarah Williams", studentId: "S1004", date: new Date("2025-03-04"), entryTime: "12:45", exitTime: "15:15", duration: 2.5 },
  { name: "David Brown", studentId: "S1005", date: new Date("2025-03-05"), entryTime: "11:15", exitTime: "14:45", duration: 3.5 },
  { name: "Emma Jones", studentId: "S1006", date: new Date("2025-03-06"), entryTime: "13:30", exitTime: "16:00", duration: 2.5 },
  { name: "Alex Johnson", studentId: "S1001", date: new Date("2025-03-10"), entryTime: "09:45", exitTime: "12:15", duration: 2.5 },
  { name: "Maria Garcia", studentId: "S1002", date: new Date("2025-03-11"), entryTime: "10:30", exitTime: "13:00", duration: 2.5 },
  { name: "James Smith", studentId: "S1003", date: new Date("2025-03-12"), entryTime: "08:00", exitTime: "11:30", duration: 3.5 },
  { name: "Sarah Williams", studentId: "S1004", date: new Date("2025-03-13"), entryTime: "12:15", exitTime: "14:45", duration: 2.5 },
  { name: "David Brown", studentId: "S1005", date: new Date("2025-03-17"), entryTime: "11:45", exitTime: "15:15", duration: 3.5 },
  { name: "Emma Jones", studentId: "S1006", date: new Date("2025-03-18"), entryTime: "14:00", exitTime: "16:30", duration: 2.5 },

  // Additional records with varied durations
  { name: "Alex Johnson", studentId: "S1001", date: new Date("2025-01-19"), entryTime: "09:00", exitTime: "12:00", duration: 3.0 },
  { name: "Maria Garcia", studentId: "S1002", date: new Date("2025-01-20"), entryTime: "10:15", exitTime: "12:45", duration: 2.5 },
  { name: "James Smith", studentId: "S1003", date: new Date("2025-01-21"), entryTime: "08:45", exitTime: "10:45", duration: 2.0 },
  { name: "Sarah Williams", studentId: "S1004", date: new Date("2025-01-22"), entryTime: "12:30", exitTime: "16:00", duration: 3.5 },
  { name: "David Brown", studentId: "S1005", date: new Date("2025-01-23"), entryTime: "11:00", exitTime: "14:00", duration: 3.0 },
  { name: "Emma Jones", studentId: "S1006", date: new Date("2025-01-26"), entryTime: "13:15", exitTime: "15:45", duration: 2.5 },
  { name: "Alex Johnson", studentId: "S1001", date: new Date("2025-01-27"), entryTime: "09:30", exitTime: "13:00", duration: 3.5 },
  { name: "Maria Garcia", studentId: "S1002", date: new Date("2025-01-28"), entryTime: "10:45", exitTime: "12:15", duration: 1.5 },
  { name: "James Smith", studentId: "S1003", date: new Date("2025-01-29"), entryTime: "08:15", exitTime: "11:45", duration: 3.5 },
  { name: "Sarah Williams", studentId: "S1004", date: new Date("2025-01-30"), entryTime: "12:00", exitTime: "14:30", duration: 2.5 },

  // February additional
  { name: "David Brown", studentId: "S1005", date: new Date("2025-02-18"), entryTime: "11:30", exitTime: "14:00", duration: 2.5 },
  { name: "Emma Jones", studentId: "S1006", date: new Date("2025-02-19"), entryTime: "14:45", exitTime: "17:15", duration: 2.5 },
  { name: "Alex Johnson", studentId: "S1001", date: new Date("2025-02-23"), entryTime: "09:15", exitTime: "12:45", duration: 3.5 },
  { name: "Maria Garcia", studentId: "S1002", date: new Date("2025-02-24"), entryTime: "10:00", exitTime: "12:00", duration: 2.0 },
  { name: "James Smith", studentId: "S1003", date: new Date("2025-02-25"), entryTime: "08:30", exitTime: "11:00", duration: 2.5 },
  { name: "Sarah Williams", studentId: "S1004", date: new Date("2025-02-26"), entryTime: "12:15", exitTime: "15:45", duration: 3.5 },

  // March additional
  { name: "David Brown", studentId: "S1005", date: new Date("2025-03-19"), entryTime: "11:00", exitTime: "13:30", duration: 2.5 },
  { name: "Emma Jones", studentId: "S1006", date: new Date("2025-03-20"), entryTime: "13:45", exitTime: "16:15", duration: 2.5 },
  { name: "Alex Johnson", studentId: "S1001", date: new Date("2025-03-24"), entryTime: "09:30", exitTime: "12:00", duration: 2.5 },
  { name: "Maria Garcia", studentId: "S1002", date: new Date("2025-03-25"), entryTime: "10:15", exitTime: "13:45", duration: 3.5 },
  { name: "James Smith", studentId: "S1003", date: new Date("2025-03-26"), entryTime: "08:45", exitTime: "10:45", duration: 2.0 },
  { name: "Sarah Williams", studentId: "S1004", date: new Date("2025-03-27"), entryTime: "12:30", exitTime: "15:00", duration: 2.5 },
  { name: "David Brown", studentId: "S1005", date: new Date("2025-03-31"), entryTime: "11:15", exitTime: "14:45", duration: 3.5 }
];

// Insert function
async function seedDatabase() {
  try {
    await Attendance.deleteMany({}); // Clear existing data
    await Attendance.insertMany(sampleData);
    console.log('✅ Database seeded successfully with 50 records!');
    process.exit(0);
  } catch (err) {
    console.error('❌ Error seeding database:', err);
    process.exit(1);
  }
}

seedDatabase();